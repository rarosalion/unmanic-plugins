**<span style="color:#56adda">0.0.2</span>**
- Check if subtitle or data exist before execute

**<span style="color:#56adda">0.0.1</span>**
- Initial version
